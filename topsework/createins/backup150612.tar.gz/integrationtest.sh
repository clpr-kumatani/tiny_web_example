#!/bin/bash

#####################################################
# MACRO
#####################################################
#------------------------------------
# COMMAND
#------------------------------------

#------------------------------------
# Parameters
#------------------------------------
WORKDIR=$HOME/createins
ExEnvPATHtmp=/tmp/ExEnvPath.$3
echo ${ExEnvPATHtmp}

WEBAPICONF=/opt/axsh/tiny-web-example/spec_integration/config/webapi.conf
IPADDR_WEB="10.0.22.111"

##################################################
# main
##################################################
# Work Directry
cd /opt/axsh/tiny-web-example/spec_integration/config
cp -p ${WEBAPICONF}.example ${WEBAPICONF}

echo "modify config file"
sed -i -e "s/localhost/${IPADDR_WEB}/g" ${WEBAPICONF}

# Integration Test running
cd /opt/axsh/tiny-web-example/spec_integration
/root/.rbenv/shims/bundle exec rspec ./spec/webapi_integration_spec.rb
