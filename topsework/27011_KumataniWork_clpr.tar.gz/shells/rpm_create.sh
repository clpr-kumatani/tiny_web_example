#!/bin/bash

RPMROOT=${HOME}/rpmbuild
RPMSDIR=${RPMROOT}/RPMS/

echo "cd ${RPMSDIR}"
